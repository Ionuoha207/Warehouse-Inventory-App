package com.example.app.ui.inventory.crud.add;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.app.R;
import com.example.app.data.database.DatabaseHelper;
import com.example.app.data.database.localdao.InventoryDAO;
import com.example.app.data.models.InventoryItem;

public class AddStockActivity extends AppCompatActivity {

    private EditText editTextItemName;
    private EditText editTextQuantity;
    private Button btnAddStock;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_stock);

        dbHelper = new DatabaseHelper(this);

        editTextItemName = findViewById(R.id.editTextItemName);
        editTextQuantity = findViewById(R.id.editTextQuantity);
        btnAddStock = findViewById(R.id.btnAddStock);

        btnAddStock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addStock();
            }
        });
    }

    private void addStock() {
        String itemName = editTextItemName.getText().toString().trim();
        String quantityStr = editTextQuantity.getText().toString().trim();

        if (!TextUtils.isEmpty(itemName) && !TextUtils.isEmpty(quantityStr)) {
            int quantity = Integer.parseInt(quantityStr);

            SQLiteDatabase db = dbHelper.getWritableDatabase();
            InventoryDAO inventoryDAO = new InventoryDAO(db);

            // Create a new InventoryItem and insert it into the database
            InventoryItem newItem = new InventoryItem(itemName, quantity);
            long newRowId = inventoryDAO.insertInventoryItem(newItem);

            if (newRowId != -1) {
                // Successfully added to inventory
                Toast.makeText(this, "Stock added successfully", Toast.LENGTH_SHORT).show();
                // You can add additional logic here, such as updating UI or navigating back.
                finish(); // Finish the AddStockActivity
            } else {
                // Failed to add to inventory
                Toast.makeText(this, "Failed to add stock", Toast.LENGTH_SHORT).show();
            }

            db.close();
        } else {
            // Show a message indicating missing fields
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
        }
    }
}