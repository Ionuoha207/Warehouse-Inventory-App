package com.example.app.data.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.app.data.models.InventoryItem;
import com.example.app.data.models.User;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "app_database";
    private static final int DATABASE_VERSION = 1;

    // User table schema
    private static final String CREATE_TABLE_USER = "CREATE TABLE IF NOT EXISTS users " +
            "(id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT, username TEXT, password TEXT)";

    // Inventory table schema
    private static final String CREATE_TABLE_INVENTORY = "CREATE TABLE IF NOT EXISTS inventory " +
            "(id INTEGER PRIMARY KEY AUTOINCREMENT, itemName TEXT, quantity INTEGER)";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USER);
        db.execSQL(CREATE_TABLE_INVENTORY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Implement database upgrade if needed
    }

    public List<InventoryItem> getAllInventoryItems() {
        List<InventoryItem> itemList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        // Query to fetch all inventory items
        Cursor cursor = db.query("inventory", null, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                long itemId = cursor.getLong(cursor.getColumnIndex("id"));
                String itemName = cursor.getString(cursor.getColumnIndex("itemName"));
                int quantity = cursor.getInt(cursor.getColumnIndex("quantity"));

                // Create InventoryItem object and add to the list
                InventoryItem item = new InventoryItem(itemId, itemName, quantity);
                itemList.add(item);
            } while (cursor.moveToNext());

            cursor.close();
        }

        db.close();
        return itemList;
    }

    public List<User> getAllUsers() {
        List<User> userList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        // Query to fetch all users
        Cursor cursor = db.query("users", null, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                long userId = cursor.getLong(cursor.getColumnIndex("id"));
                String username = cursor.getString(cursor.getColumnIndex("username"));
                String email = cursor.getString(cursor.getColumnIndex("email"));

                // Create InventoryItem object and add to the list
                User user = new User(userId, username, email);
                userList.add(user);
            } while (cursor.moveToNext());

            cursor.close();
        }

        db.close();
        return userList;
    }

    //    Update Stock
    public void updateInventoryItemQuantity(long itemId, int newQuantity) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("quantity", newQuantity);

        // Update the item in the database
        db.update("inventory", values, "id=?", new String[]{String.valueOf(itemId)});

        db.close();
    }

    //    Delete stock
    public void deleteInventoryItem(long itemId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("inventory", "id=?", new String[]{String.valueOf(itemId)});
        db.close();
    }
}
