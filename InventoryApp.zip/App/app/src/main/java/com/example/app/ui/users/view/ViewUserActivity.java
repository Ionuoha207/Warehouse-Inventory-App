package com.example.app.ui.users.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.app.R;
import com.example.app.data.database.DatabaseHelper;
import com.example.app.data.models.InventoryItem;
import com.example.app.data.models.User;
import com.example.app.ui.inventory.adapter.InventoryAdapter;
import com.example.app.ui.users.adapter.UserAdapter;

import java.util.ArrayList;
import java.util.List;

public class ViewUserActivity extends AppCompatActivity {

    private RecyclerView recyclerViewUser;
    private UserAdapter userAdapter;
    private List<User> userList;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_user);

        dbHelper = new DatabaseHelper(this);

        recyclerViewUser = findViewById(R.id.recyclerViewUser);
        userList = new ArrayList<>(); // Initialize your data source

        // Set up RecyclerView
        userAdapter = new UserAdapter(this, userList);
        recyclerViewUser.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewUser.setAdapter(userAdapter);

        // Fetch data from the database and update the adapter
        fetchUserDataFromDatabase();
    }

    private void fetchUserDataFromDatabase() {
        List<User> fetchedItems = dbHelper.getAllUsers();
        userList.addAll(fetchedItems);

        // Notify the adapter that the data set has changed
        userAdapter.notifyDataSetChanged();
    }
}