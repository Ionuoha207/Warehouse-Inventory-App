package com.example.app.ui.inventory.adapter;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.R;
import com.example.app.data.models.InventoryItem;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    private final List<InventoryItem> inventoryItemList;
    private final Context context;

    public interface OnItemClickListener {
        void onDeleteClick(int position);
    }

    // Inside InventoryAdapter
    private static OnItemClickListener listener;

    public static void setOnItemClickListener(OnItemClickListener listener) {
        InventoryAdapter.listener = listener;
    }

    public InventoryAdapter(Context context, List<InventoryItem> inventoryItemList) {
        this.context = context;
        this.inventoryItemList = inventoryItemList;
    }

    public void removeItem(int position) {
        inventoryItemList.remove(position);
        notifyItemRemoved(position);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem item = inventoryItemList.get(position);

        holder.textViewItemID.setText("Item ID: " + item.getId());
        holder.textViewItemName.setText(item.getItemName());
        holder.textViewQuantity.setText(String.valueOf(item.getQuantity()));
    }

    @Override
    public int getItemCount() {
        return inventoryItemList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView textViewItemID;
        TextView textViewItemName;
        TextView textViewQuantity;
        AppCompatImageView updateStock;
        AppCompatImageView deleteStock;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewItemID = itemView.findViewById(R.id.textViewItemID);
            textViewItemName = itemView.findViewById(R.id.textViewItemName);
            textViewQuantity = itemView.findViewById(R.id.textViewItemQuantity);
            updateStock = itemView.findViewById(R.id.update_stock);
            deleteStock = itemView.findViewById(R.id.delete_stock);

            // Set the click listener for the delete icon
            updateStock.setOnClickListener(this);
            deleteStock.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            // Handle delete icon click
            final int position = getAdapterPosition();
            if (position != RecyclerView.NO_POSITION) {
                if (view.getId() == R.id.delete_stock) {
                    if (listener != null) {
                        listener.onDeleteClick(position);
                    }
                } else if (view.getId() == R.id.update_stock) {
                    // Handle the click event to update the stock
                    updateStockQuantity(position);
                }
            }
        }

        private void updateStockQuantity(int position) {
            // Retrieve the item at the clicked position
            InventoryItem clickedItem = inventoryItemList.get(position);

            // Create a layout for the dialog
            View dialogLayout = LayoutInflater.from(context).inflate(R.layout.dialog_update_stock, null);

            // Find views in the dialog layout
            EditText editTextUpdatedItemName = dialogLayout.findViewById(R.id.editTextUpdatedItemName);
            EditText editTextUpdatedQuantity = dialogLayout.findViewById(R.id.editTextUpdatedItemQuantity);

            // Populate the view with the existing item quantity
            editTextUpdatedItemName.setText(clickedItem.getItemName());
            editTextUpdatedQuantity.setText(String.valueOf(clickedItem.getQuantity()));

            // Build an AlertDialog
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("Update Stock Quantity");
            builder.setView(dialogLayout);

            builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // Get the updated quantity from the dialog
                    int updatedQuantity = Integer.parseInt(editTextUpdatedQuantity.getText().toString().trim());

                    // Update the quantity in the data source
                    clickedItem.setQuantity(updatedQuantity);

                    // Notify the adapter that the data has changed
                    notifyItemChanged(getAdapterPosition());

                    showNotification("Item Updated", "Item ID: " + clickedItem.getId() + " updated successfully");
                }
            });

            builder.setNegativeButton("Cancel", null);

            builder.show();
        }

        private void showNotification(String title, String message) {
            NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "channel_id")
                    .setSmallIcon(R.drawable.add_alert)
                    .setContentTitle(title)
                    .setContentText(message)
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT);

            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            notificationManager.notify(1, builder.build()); // Use a unique ID for each notification
        }
    }
}
