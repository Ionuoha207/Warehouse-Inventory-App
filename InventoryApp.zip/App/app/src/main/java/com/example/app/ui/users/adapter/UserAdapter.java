package com.example.app.ui.users.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.R;
import com.example.app.data.models.InventoryItem;
import com.example.app.data.models.User;
import com.example.app.ui.inventory.adapter.InventoryAdapter;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {

    private List<User> userList;
    private Context context;

    public UserAdapter(Context context, List<User> userList) {
        this.context = context;
        this.userList = userList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_user, parent, false);
        return new UserAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        User item = userList.get(position);

        holder.textViewUserID.setText("ID: " + item.getId());
        holder.textViewUserName.setText(item.getUserName());
        holder.textViewUserEmail.setText(String.valueOf(item.getUserEmail()));
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewUserID;
        TextView textViewUserName;
        TextView textViewUserEmail;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewUserID = itemView.findViewById(R.id.textViewUserID);
            textViewUserName = itemView.findViewById(R.id.textViewUserName);
            textViewUserEmail = itemView.findViewById(R.id.textViewUserEmail);
        }
    }
}
