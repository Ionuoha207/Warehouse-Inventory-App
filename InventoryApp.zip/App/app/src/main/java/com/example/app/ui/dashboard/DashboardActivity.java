package com.example.app.ui.dashboard;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.app.R;
import com.example.app.ui.inventory.InventoryDashboardActivity;
import com.example.app.ui.users.view.ViewUserActivity;
import com.google.android.material.card.MaterialCardView;

public class DashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        MaterialCardView cardInventory = findViewById(R.id.card_inventory);
        MaterialCardView cardPeople = findViewById(R.id.card_people);

        // Set click listeners for the card views
        cardInventory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click for "Add Stock" card view
                Toast.makeText(DashboardActivity.this, "View Inventory Clicked", Toast.LENGTH_SHORT).show();
                // You can add code here to navigate to the Add Stock activity or perform other actions.
                viewInventory();
            }
        });

        cardPeople.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click for "View Stock" card view
                Toast.makeText(DashboardActivity.this, "View People Clicked", Toast.LENGTH_SHORT).show();
                // You can add code here to navigate to the View Stock activity or perform other actions.
                viewUser();
            }
        });
    }

    private void viewInventory() {
        Intent intent = new Intent(this, InventoryDashboardActivity.class);
        startActivity(intent);
    }

    private void viewUser() {
        Intent intent = new Intent(this, ViewUserActivity.class);
        startActivity(intent);
    }
}