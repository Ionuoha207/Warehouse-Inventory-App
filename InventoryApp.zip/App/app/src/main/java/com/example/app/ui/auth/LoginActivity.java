package com.example.app.ui.auth;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.app.R;
import com.example.app.data.database.DatabaseHelper;
import com.example.app.ui.dashboard.DashboardActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editTextUsername, editTextPassword;
    private Button btnLogin, btnSignUp;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnSignUp = findViewById(R.id.btnSignUp);

        dbHelper = new DatabaseHelper(this);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                redirectToRegistration();
            }
        });
    }

    private void login() {
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username=? AND password=?", new String[]{username, password});

        if (cursor.getCount() > 0) {
            // Login successful
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
            dashboard();

            //  clear input fields
            editTextUsername.setText("");
            editTextPassword.setText("");
        } else if(cursor.getCount() == 0) {
            // User not present
            Toast.makeText(this, "User is Not Found", Toast.LENGTH_SHORT).show();
            redirectToRegistration();
        } else {
            // Invalid username or password
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }

        cursor.close();
        db.close();
    }

    private void dashboard() {
        Intent intent = new Intent(this, DashboardActivity.class);
        startActivity(intent);
    }
    private void redirectToRegistration() {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }

//    private void register() {
//        String username = editTextUsername.getText().toString().trim();
//        String password = editTextPassword.getText().toString().trim();
//
//        SQLiteDatabase db = dbHelper.getWritableDatabase();
//
//        // Check if the username already exists
//        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username=?", new String[]{username});
//
//        if (cursor.getCount() > 0) {
//            // Username already exists
//            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
//        } else {
//            // Insert new user
//            ContentValues values = new ContentValues();
//            values.put("username", username);
//            values.put("password", password);
//
//            long newRowId = db.insert("users", null, values);
//
//            if (newRowId != -1) {
//                // Registration successful
//                Toast.makeText(this, "Registration Successful", Toast.LENGTH_SHORT).show();
//            } else {
//                // Registration failed
//                Toast.makeText(this, "Registration Failed", Toast.LENGTH_SHORT).show();
//            }
//        }
//
//        cursor.close();
//        db.close();
//    }
}
