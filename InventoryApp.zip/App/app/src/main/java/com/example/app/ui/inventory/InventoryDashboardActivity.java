package com.example.app.ui.inventory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.app.R;
import com.example.app.ui.inventory.crud.add.AddStockActivity;
import com.example.app.ui.inventory.crud.view.ViewStockActivity;
import com.google.android.material.card.MaterialCardView;

public class InventoryDashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_dashboard);

        MaterialCardView cardAdd = findViewById(R.id.card_add);
        MaterialCardView cardViewInventory = findViewById(R.id.card_view_inventory);

        // Set click listeners for the card views
        cardAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click for "Add Stock" card view
                Toast.makeText(InventoryDashboardActivity.this, "Add Stock Clicked", Toast.LENGTH_SHORT).show();

                addStock();
            }
        });

        cardViewInventory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click for "View Stock" card view
                Toast.makeText(InventoryDashboardActivity.this, "View Stock Clicked", Toast.LENGTH_SHORT).show();

                viewStock();
            }
        });
    }

    private void addStock() {
        Intent intent = new Intent(this, AddStockActivity.class);
        startActivity(intent);
    }

    private void viewStock() {
        Intent intent = new Intent(this, ViewStockActivity.class);
        startActivity(intent);
    }
}