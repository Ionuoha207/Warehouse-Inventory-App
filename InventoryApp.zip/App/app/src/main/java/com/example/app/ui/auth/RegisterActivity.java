package com.example.app.ui.auth;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.app.R;
import com.example.app.data.database.DatabaseHelper;

public class RegisterActivity extends AppCompatActivity {

    private EditText editTextEmail, editTextUsername, editTextPassword, editTextConfirmPassword;
    private Button btnSignUp;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        dbHelper = new DatabaseHelper(this);

        editTextEmail = findViewById(R.id.editTextEmail);
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword);
        btnSignUp = findViewById(R.id.btnSignUp);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });
    }

    private void registerUser() {
        String email = editTextEmail.getText().toString().trim();
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String confirmPassword = editTextConfirmPassword.getText().toString().trim();

        if (password.equals(confirmPassword)) {
            // Passwords match, proceed with registration

            SQLiteDatabase db = dbHelper.getWritableDatabase();

            // Check if the username already exists
            if (isUsernameExists(username, db)) {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            } else {
                // Insert new user
                ContentValues values = new ContentValues();
                values.put("email", email);
                values.put("username", username);
                values.put("password", password);

                long newRowId = db.insert("users", null, values);

                if (newRowId != -1) {
                    // Registration successful
                    Toast.makeText(this, "Registration Successful", Toast.LENGTH_SHORT).show();
                    // You can add additional logic here, such as starting a new activity or updating UI.
                    // For example, you might want to redirect the user to the login screen.
                    finish(); // Finish the registration activity
                } else {
                    // Registration failed
                    Toast.makeText(this, "Registration Failed", Toast.LENGTH_SHORT).show();
                }
            }

            db.close();
        } else {
            // Passwords do not match
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isUsernameExists(String username, SQLiteDatabase db) {
        // Check if the username already exists in the database
        String[] columns = {"username"};
        String selection = "username=?";
        String[] selectionArgs = {username};

        return db.query("users", columns, selection, selectionArgs, null, null, null)
                .getCount() > 0;
    }
}
