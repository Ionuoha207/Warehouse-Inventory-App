package com.example.app.data.database.localdao;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;

import com.example.app.data.models.InventoryItem;

public class InventoryDAO {

    private SQLiteDatabase db;

    public InventoryDAO(SQLiteDatabase db) {
        this.db = db;
    }

    public long insertInventoryItem(InventoryItem item) {
        ContentValues values = new ContentValues();
        values.put("itemName", item.getItemName());
        values.put("quantity", item.getQuantity());

        return db.insert("inventory", null, values);
    }

    public int updateInventoryItem(InventoryItem item) {
        ContentValues values = new ContentValues();
        values.put("itemName", item.getItemName());
        values.put("quantity", item.getQuantity());

        // Update the record in the database
        return db.update("inventory", values, "id=?", new String[]{String.valueOf(item.getId())});
    }

}
