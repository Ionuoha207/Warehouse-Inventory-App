package com.example.app.ui.inventory.crud.view;

import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.R;
import com.example.app.data.database.DatabaseHelper;
import com.example.app.data.models.InventoryItem;
import com.example.app.ui.inventory.adapter.InventoryAdapter;

import java.util.ArrayList;
import java.util.List;

public class ViewStockActivity extends AppCompatActivity implements InventoryAdapter.OnItemClickListener {

    private RecyclerView recyclerViewInventory;
    private InventoryAdapter inventoryAdapter;
    private List<InventoryItem> inventoryItemList;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_stock);

        dbHelper = new DatabaseHelper(this);

        recyclerViewInventory = findViewById(R.id.recyclerViewInventory);
        inventoryItemList = new ArrayList<>(); // Initialize your data source

        // Set up RecyclerView
        inventoryAdapter = new InventoryAdapter(this, inventoryItemList);
        recyclerViewInventory.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerViewInventory.setAdapter(inventoryAdapter);

        // Fetch data from the database and update the adapter
        fetchDataFromDatabase();

        // Set the click listener
        inventoryAdapter.setOnItemClickListener(this);
    }

//    @Override
//    public void onUpdateStockConfirmed(String updatedItemName, int updatedQuantity) {
//        InventoryItem updatedItem = inventoryItemList.get(selectedPosition);
//        updatedItem.setItemName(updatedItemName);
//        updatedItem.setQuantity(updatedQuantity);
//
//        // Notify the adapter that the data has changed
//        inventoryAdapter.notifyItemChanged(selectedPosition);
//    }

    // Handle delete click
    @Override
    public void onDeleteClick(int position) {
        showDeleteConfirmationDialog(position);
    }

    private void fetchDataFromDatabase() {
        List<InventoryItem> fetchedItems = dbHelper.getAllInventoryItems();
        inventoryItemList.addAll(fetchedItems);

        // Notify the adapter that the data set has changed
        inventoryAdapter.notifyDataSetChanged();
    }

    // Show a confirmation dialog for item deletion
    private void showDeleteConfirmationDialog(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Item");
        builder.setMessage("Are you sure you want to delete this item?");
        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteItem(position);
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void deleteItem(int position) {
        // Ensure the position is valid
        if (position >= 0 && position < inventoryItemList.size()) {
            InventoryItem itemToDelete = inventoryItemList.get(position);

            // Remove the item from the database
            dbHelper.deleteInventoryItem(itemToDelete.getId());

            // Remove the item from the RecyclerView
            inventoryAdapter.removeItem(position);
        }
    }
}